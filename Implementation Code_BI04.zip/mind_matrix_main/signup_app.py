from flask import Flask, request, redirect, render_template_string, render_template
import mysql.connector
import hashlib

app = Flask(__name__)

# Database configuration
db_config = {
    'user': 'Mansi',
    'password': 'Mrp@182002',
    'host': 'localhost',
    'database': 'MindMatrix'
}

# Connect to MySQL database
db = mysql.connector.connect(**db_config)
cursor = db.cursor()

# Create users table if it doesn't exist
cursor.execute("""
    CREATE TABLE IF NOT EXISTS user(
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) NOT NULL,
        password VARCHAR(255) NOT NULL
    )
""")
db.commit()

@app.route('/')
def index():
    #return render_template_string(open('templates/signup.html').read())
    return render_template('signup.html')

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
    
        # Hash the password for security
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
        try:
            cursor.execute("INSERT INTO user (username, email, password) VALUES (%s,%s,%s)", (username, email, hashed_password))
            db.commit()
            return "User registered successfully!"
        
        except mysql.connector.IntegrityError:
            return "Username already exists!"
    
    return render_template('signup.html')


'''
@app.route('/login', methods=['POST'])
def login():
    
    email= request.form['email']
    password = request.form['password']
    
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
    cursor.execute("SELECT * FROM user WHERE email = %s AND password = %s", (email, hashed_password))
    user = cursor.fetchone()
    
    if user:
        return "Login successful!"
    else:
        return "Invalid username or password!"

        '''
        

if __name__ == '__main__':
    app.run(debug=True)