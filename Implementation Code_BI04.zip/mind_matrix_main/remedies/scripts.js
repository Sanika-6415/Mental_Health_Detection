document.addEventListener('DOMContentLoaded', function() {
    console.log("Document is ready");
    // Add any interactive JS here
});
