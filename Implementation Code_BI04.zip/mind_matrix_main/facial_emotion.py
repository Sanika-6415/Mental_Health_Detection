import numpy as np
import cv2


from keras.models import model_from_json

emotion_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy", 4: "Neutral", 5: "Sad", 6: "Surprised"}

# Load json and create model
json_file = open('model/emotion_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
emotion_model = model_from_json(loaded_model_json)

# Load weights into new model
emotion_model.load_weights("model/emotion_model.h5")
print("Loaded model from disk")

# Start the webcam feed
cap = cv2.VideoCapture(0)

# Data structure to store emotion counts
emotion_counts = {emotion: 0 for emotion in emotion_dict.values()}
previous_mouse_click = False  # Flag to track previous click state

def handle_mouse_click(event, x, y, flags, param):
    global previous_mouse_click
    if event == cv2.EVENT_LBUTTONDOWN and not previous_mouse_click:
        # Capture frame on left mouse click down (avoiding multiple captures)
        previous_mouse_click = True
        ret, frame = cap.read()
        frame = cv2.resize(frame, (1280, 720))
        if not ret:
            return

        # Process the captured frame
        face_detector = cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_default.xml')
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        num_faces = face_detector.detectMultiScale(gray_frame, scaleFactor=1.3, minNeighbors=5)

        for (x, y, w, h) in num_faces:
            cv2.rectangle(frame, (x, y-50), (x+w, y+h+10), (0, 255, 0), 4)
            roi_gray_frame = gray_frame[y:y + h, x:x + w]
            cropped_img = np.expand_dims(np.expand_dims(cv2.resize(roi_gray_frame, (48, 48)), -1), 0)

            # Predict emotions
            emotion_prediction = emotion_model.predict(cropped_img)
            maxindex = int(np.argmax(emotion_prediction))

            # Update emotion counts
            detected_emotion = emotion_dict[maxindex]
            emotion_counts[detected_emotion] += 1

            # Print detected emotion to terminal
            print(f"Detected emotion: {detected_emotion}")

            # Display emotion on frame
            cv2.putText(frame, detected_emotion, (x+5, y-20), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

        cv2.imshow('Emotion Detection', frame)

# Set mouse callback function
cv2.namedWindow('Emotion Detection')

cv2.setMouseCallback('Emotion Detection', handle_mouse_click)

while True:
    # Display frame
    _, frame = cap.read()  # Capture frame for display (not processing)
    frame = cv2.resize(frame, (1280, 720))
    cv2.imshow('Emotion Detection', frame)

    # Exit on 'q' key press
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break

    # Reset click flag after processing on click
    previous_mouse_click = False

# Find the emotion with the highest count (same as before)
max_count = max(emotion_counts.values())
most_frequent_emotions = [emotion for emotion, count in emotion_counts.items() if count == max_count]

print("\nAfter stopping with 'q':")
if len(most_frequent_emotions) == 1:
    print(f"The most frequent emotion detected was: {most_frequent_emotions[0]}")
else:
    print(f"There was a tie for most frequent emotions:")
    for emotion in most_frequent_emotions:
        print(f"- {emotion}")

cap.release()
cv2.destroyAllWindows()