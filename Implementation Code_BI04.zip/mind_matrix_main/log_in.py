from flask import Flask, request, redirect, render_template_string, render_template, flash, url_for, redirect, session
import mysql.connector
import hashlib
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Database configuration
db_config = {
    'user': 'Mansi',
    'password': 'Mrp@182002',
    'host': 'localhost',
    'database': 'MindMatrix'
}

db = mysql.connector.connect(**db_config)
cursor = db.cursor()

@app.route('/')
def index():
    #return render_template_string(open('templates/signup.html').read())
    return render_template('log_in.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        email= request.form['email']
        password = request.form['password']
    
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
        cursor.execute("SELECT * FROM user WHERE email = %s AND password = %s", (email, hashed_password))
        user = cursor.fetchone()
    
        if user:
            session['logged_in'] = True
            flash('You are now logged in', 'success')
            #return redirect(url_for('index'))
            return "Login successful!"
        else:
            return "Invalid username or password!"
    
    return render_template('log_in.html')
        

if __name__ == '__main__':
    app.run(debug=True)