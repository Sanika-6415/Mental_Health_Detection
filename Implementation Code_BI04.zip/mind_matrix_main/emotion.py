from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
from keras.models import model_from_json
import base64

app = Flask(__name__)

emotion_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy", 4: "Neutral", 5: "Sad", 6: "Surprised"}

# Load json and create model
json_file = open('model/emotion_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
emotion_model = model_from_json(loaded_model_json)

# Load weights into new model
emotion_model.load_weights("model/emotion_model.h5")
print("Loaded model from disk")

# Data structure to store emotion counts
emotion_counts = {emotion: 0 for emotion in emotion_dict.values()}

def detect_emotion(frame):
    face_detector = cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_default.xml')
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    num_faces = face_detector.detectMultiScale(gray_frame, scaleFactor=1.3, minNeighbors=5)

    detected_emotion = None
    for (x, y, w, h) in num_faces:
        cv2.rectangle(frame, (x, y-50), (x+w, y+h+10), (0, 255, 0), 4)
        roi_gray_frame = gray_frame[y:y + h, x:x + w]
        cropped_img = np.expand_dims(np.expand_dims(cv2.resize(roi_gray_frame, (48, 48)), -1), 0)

        # Predict emotions
        emotion_prediction = emotion_model.predict(cropped_img)
        maxindex = int(np.argmax(emotion_prediction))

        # Update emotion counts
        detected_emotion = emotion_dict[maxindex]
        emotion_counts[detected_emotion] += 1

        # Print detected emotion to terminal
        print(f"Detected emotion: {detected_emotion}")

        # Display emotion on frame
        cv2.putText(frame, detected_emotion, (x+5, y-20), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

    return detected_emotion

@app.route('/')
def index():
    return render_template('emotion.html')

@app.route('/detect_emotion', methods=['POST'])
def detect_emotion_route():
    # Get image data from request
    image_data = request.json.get('image_data')
    # Decode image data
    nparr = np.frombuffer(base64.b64decode(image_data.split(',')[1]), np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # Detect emotion in the image
    detected_emotion = detect_emotion(img)
    
    if detected_emotion:
        return jsonify({'emotion': detected_emotion})
    else:
        return jsonify({'emotion': 'No face detected'})

if __name__ == "__main__":
    app.run(debug=True)